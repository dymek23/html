function ShowLanguages()
{
	var Element = document.getElementById('vt_languages_list');
	Element.style.display = 'block';
}

function HideLanguages()
{
	var Element = document.getElementById('vt_languages_list');
	Element.style.display = 'none';
}

function initLanguageBox()
{
	HideLanguages();
}