<?php
$_GET['subtopic'] = 'zaypay_report';
$_REQUEST['subtopic'] = 'zaypay_report';
include('index.php');