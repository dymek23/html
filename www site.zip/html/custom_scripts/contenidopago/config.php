<?PHP
$contenidopago_active = false; // change it to make that system works!
$idOfService = 11253; // your service ID [make new 'tibia auto']
$points = 1; // points for SMS
$report_url = 'http://yourdomain.com/contenidopago_report.php'; // set it also on contenidopago when you register 'tibia auto'