<?PHP
$main_content .= '<br />
<center>
<td>
<img src="http://i64.tinypic.com/2nvywsh.png">
<br><br>

-RECOMPENSA DO EVENTO ~~ 5 SILVER TOKEN ~~ PODE SER TROCADO NO NPC Bozarn em Darashia, localização na entrada ferumbras ascendant
- O TELEPORT SE LOCALIZA EM THAIS A ESQUERDA DO TEMPLO!!
- O evento &eacute autom&aacutetico e acontece em determinado dia e hora da semana<br>
- Logo ap&oacutes &eacute aberto um teleport ent&atildeo apenar um n&uacutemero limitado de players entra no evento<br>
- S&aacuteo formados por dois times, os "Black Assassins" e os "Red Barbarians"<br>
- Os times s&atildeo balanceados automaticamente, quando o &uacuteltimo jogador entra, esse teleport &eacute fechado e depois de 5 minutos o evento come&ccedila, os 5 minutos s&atildeo para os players ter tempo de planejar um ataque.<br>
- O sistema tem por finalidade matar todos do time inimigo, e os players que sobreviverem recebem um pr&ecircmio.<br>
<br><br>
<b>OBS:</b> N&atildeo perde level, skills e nem items dentro do evento!
<br>
<br>
<br>
<br>
<b>V&iacutedeo de demonstra&ccedil&atildeo:</b>
<br>
<br>
<object width="425" height="355"><param name="movie" value="http://www.youtube.com/v/PQ8Mnw4K72o&rel=1"></param><param name="wmode" value="transparent"></param><embed src="http://www.youtube.com/v/PQ8Mnw4K72o&rel=1" type="application/x-shockwave-flash" wmode="transparent" width="425" height="355"></embed></object>
</link>
</table>
</td>
</table>
';
?>